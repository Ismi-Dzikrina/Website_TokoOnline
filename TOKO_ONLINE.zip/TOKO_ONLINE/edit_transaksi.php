<?php
	require "functions_transaksi.php";
	$id_transaksi = $_GET["id_transaksi"];
	$tr = query("SELECT * FROM transaksi WHERE id_transaksi=$id_transaksi")[0];

	
	//cek tombol submit sudan ditekan apa belum
	if (isset($_POST['submit'])) {
	
		//cek jika data berhasil ditambahkan ,>0 artinya ada baris data yang berubah didb
		if(edit($_POST) > 0){
			echo "
					<script>
						alert('data berhasil diedit');
						document.location.href='transaksi.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal diedit');
						document.location.href='transaksi.php';
					</script>
			";
		}
		}
?>

<!DOCTYPE html>
<html>
<head>
	<title>transaksi</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">
</head>
<body>
	<div class="container">

	<!-- awalcard form .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header bg-secondary text-white text-center lead">
	    FORM EDIT DATA TRANSAKSI
	  </div>
	  <div class="card-body">
	  	<form method="post" action="">
	  		<input type="hidden" name="id_transaksi" value="<?=$tr["id_transaksi"]; ?>">
	  		
	  		<div class="form-group">
	  			<label class="lead">Id Pelanggan</label>
	  			<input type="text" class="form-control" name="id_pelanggan" readonly value="<?=$tr["id_pelanggan"];?>" required/>	  			
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Id Barang</label>
	  			<input type="text" class="form-control" name="id_barang" readonly value="<?=$tr["id_barang"];?>" required/>	  
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Tanggal</label>
	  			<input type="date" name="tgl" class="form-control" value="<?=$tr["tgl"];?>" required/>
	  		</div>  
	  		<div class="form-group">
	  			<label class="lead">Total</label>
	  			<input type="text" name="total" class="form-control" value="<?=$tr["total"];?>">
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Keterangan</label>
	  			<input type="text" name="keterangan" class="form-control" value="<?=$tr["keterangan"];?>">
	  		</div>
	  		<button type="submit" class="btn btn-success" name="submit">Simpan</button>

	  	</form>
	  </div>
	</div>
	<!-- selesai card form -->
	</div>
<style type="text/css"> 
footer{
    clear: both;
    background-color: #DB7093; /*ungu*/
    color: white;
    padding: 15px;
    text-align: center;
}		
</style>
	<footer>
            Copyright &copy; 2020 || by ISMI DZIKRINAInformatika
    </footer>

<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>