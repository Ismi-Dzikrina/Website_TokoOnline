<?php
	require "functions_barang.php";
	$barang = query ("SELECT * FROM barang");

	//tekan tombol cari
	if (isset($_POST["cari"])) {
		$barang = cari($_POST["keyword"]);
	}
	//cek tombol submit sudan ditekan apa belum
	if (isset($_POST['submit'])) {
	
		//cek jika data berhasil ditambahkan ,>0 artinya ada baris data yang berubah didb
		if(tambah($_POST) > 0){
			echo "
					<script>
						alert('data berhasil ditambahkan');
						document.location.href='barang.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal ditambahkan');
						document.location.href='barang.php';
					</script>
			";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>barang</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">

</head>
<body>
	
	<header>
		 <div class="main">
		 	<div class="logo"><img src="gambar/logo2.gif"></div>
		 	<ul>
		 		<li><a href="home.php">Home</a></li>
		 		<li class="active"><a href="barang.php">Barang</a></li>
                <li><a href="pelanggan.php">Pelanggan</a></li>
                <li><a href="transaksi.php">Transaksi</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
		 	</ul>
		 </div>
		 <div class="button">
		 	<a href="https://www.youtube.com/watch?v=JdFS_CbRMRM" class="btn1">Tonton Video</a>
		 	<a href="index.php" class="btn2">Logout</a>
		 </div>
		 <div class="title">
		 	<h1>~~~ Highwell Online Shop ~~~</h1>
		 </div>
	</header>

	<div class="container">
	
	<!-- awalcard form .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header bg-secondary text-white text-center lead">
	    FORM INPUT DATA BARANG
	  </div>
	  <div class="card-body">
	  	<form method="post" action="">
	  		<div class="form-group">
	  			<label class="lead">Nama Barang</label>
	  			<input type="text" name="nama_barang" class="form-control" placeholder="Masukkan nama barang disini...." required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Harga Barang</label>
	  			<input type="text" name="harga_barang" class="form-control" placeholder="Masukkan harga barang disini...." required/>
	  		</div>  
	  		<div class="form-group">
	  			<label class="lead">Stok</label>
	  			<input type="number" name="stok" min="0" max="50" class="form-control" placeholder="Masukkan stok barang disini...." required/>
	  		</div>

	  		<button type="submit" class="btn btn-success" name="submit">Simpan</button>
	  		<button type="reset" class="btn btn-danger" name="reset">Kosongkan</button>

	  	</form>
	  </div>
	</div>
	<!-- selesai card form -->

	<!-- pencarian -->
	<form action="#" method="post">
		<div class="input-group mb-3"> 
		<input type="text" name="keyword" size="40" autofocus placeholder="Masukkan kata pencarian..." autocomplete="off" id="keyword" class="form-control">
			<div class="input-group-append">
				<button type="submit" name="cari" id="tombolcari" class="btn btn-warning">Cari</button>
			</div>
		</div>
	</form>

	<!-- awalcard tabel .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header text-white bg-secondary text-center lead">
	    DATA BARANG
	  </div>
	  <div class="card-body">
	  	<table class="table table-bordered table-striped">
	  		<tr class=" text-dark text-center">
	  			<th class="text-center">No</th>
	  			<th class="text-center">Id Barang</th>
	  			<th class="text-center">Nama Barang</th>
	  			<th class="text-center">Harga Barang</th>
	  			<th class="text-center">Stok</th>
	  			<th class="text-center">Aksi</th>
	  		</tr>
	  		<?php $i = 1; ?>
	  		<?php foreach ($barang as $row) :	?> 
	  		<tr>
	  			<td><?=$i; ?></td>
	  			<td><?=$row["id_barang"]?></td>
	  			<td><?=$row["nama_barang"]?></td>
	  			<td><?=$row["harga_barang"]?></td>
	  			<td><?=$row["stok"]?></td>
	  			<td>
	  				<a href="edit_barang.php?id_barang=<?= $row["id_barang"];?>" class="btn btn-warning">Edit</a>
	  				<a href="hapus_barang.php?id_barang=<?=$row["id_barang"];?>"onclick="return confirm('apakah anda ingin menghapus data ?')" class="btn btn-danger">Hapus</a>
	  			</td>
	  		</tr>
	  		<?php $i++;?>
	  		<?php endforeach; ?>
	  	</table>
	  </div>
	</div>
	<!-- selesai card tabel -->
	</div>
<style type="text/css"> 
footer{
    clear: both;
    background-color: #DB7093; /*ungu*/
    color: white;
    padding: 15px;
    text-align: center;
}		
</style>	
	<footer>
            Copyright &copy; 2020 || by ISMI DZIKRINA Informatika
    </footer>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>