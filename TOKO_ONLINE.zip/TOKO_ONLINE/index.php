<?php

error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
$conn = mysqli_connect("localhost","root","","perpus_20");


$username = $_POST["username"];
$password = $_POST["password"];
$submit = $_POST["submit"];

if ($submit) {
	$sql = "SELECT * FROM user WHERE username='$username' AND password='$password'";
	$result = mysqli_query($conn,$sql);
	$row = mysqli_fetch_assoc($result);

	if ($row["username"]!='') {
		//berhasil login
		if ($row["level"]=="admin") {
			$_SESSION["username"] = $row["username"];
			?>
			<script language script="JavaScript">
			alert("Selamat Datang <?= $row['username'] ?>");
			document.location ="home.php";
			</script>
			<?php
		}elseif($row["level"]=="anggota"){
			$_SESSION["username"] = $row["username"];
			?>
			<script language script="JavaScript">
			alert("Anda login sebagai Anggota Perpustakaan");
			document.location ="index_anggota.php";
			</script>
		<?php }
	}else{
		//gagal login
		?>
		<script language script="JavaScript">
		alert ("gagal login");
		document.location = "index.php";
		</script>
	<?php }
}

?>

<!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <title>Login Page</title>
    <link rel="stylesheet" href="login.css" media="screen" title="no title">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
      <form method="post" accept="login.php">
      <div class="login">

          <div class="avatar">
            <i class="fa fa-user"></i>
          </div>

          <h2>Login Form</h2>

          <div class="box-login">
            <i class="fas fa-envelope-open-text"></i>
            <input type="text" placeholder="Username" name="username">
          </div>

          <div class="box-login">
            <i class="fas fa-lock"></i>
            <input type="password" placeholder="Password" name="password">
          </div>

          <input type="submit" name="submit" value="Login" class="btn-login">
          <div class="bottom">
            <a href="#">Register</a>
            <a href="#">Forgot Password</a>
          </div>
      </div>
  </form>
  </head>
  </html>