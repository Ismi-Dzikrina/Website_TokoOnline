
<!DOCTYPE html>
<html>
<head>
	<title>contact</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">
</head>
<body>
	<header>
		 <div class="main">
		 	<div class="logo"><img src="gambar/logo2.gif"></div>
		 	<ul>
		 		<li><a href="home.php">Home</a></li>
		 		<li><a href="barang.php">Barang</a></li>
                <li><a href="pelanggan.php">Pelanggan</a></li>
                <li><a href="transaksi.php">Transaksi</a></li>
                <li><a href="about.php">About</a></li>
                <li class="active"><a href="contact.php">Contact</a></li>
		 	</ul>
		 </div>
		 <div class="button">
		 	<a href="https://www.youtube.com/watch?v=JdFS_CbRMRM" class="btn1">Tonton Video</a>
		 	<a href="index.php" class="btn2">Logout</a>
		 </div>
		 <div class="title">
		 	<h1>~~~ Highwell Online Shop ~~~</h1>
		 </div>
	</header>

	<div class="container">
		<div class="card mt-3"> <!-- margin top=3 -->
			<div class="card-header bg-secondary text-white text-center lead">
	    		CONTACT INFO
	  		</div>
	  	<div class="card-body">
	  		<table class="table table-bordered table-striped">
		  		<tr class=" text-dark text-center">
		  			<th class="text-center" width="25%">Address</th>
		  			<th class="text-center" width="25%">E-mail</th>
		  			<th class="text-center" width="25%">Telp.</th>
		  			<th class="text-center" width="25%">Hp</th>
		  		</tr>
		  		<tr>
		  			<td class="text-center">Jl. Indah Raya Jawa Tengah Kode Pos 57555</td>
		  			<td class="text-center">highwell_onlineshop@gmail.com</td>
		  			<td class="text-center">0271-97252426</td>
		  			<td class="text-center">08363352252</td>
		  		</tr>
	  		</table>

			 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63265.2658886346!2d110.79153982874149!3d-7.674643619744484!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a3c13cf3788cd%3A0x4027a76e35301c0!2sSukoharjo%2C%20Kec.%20Sukoharjo%2C%20Kabupaten%20Sukoharjo%2C%20Jawa%20Tengah!5e0!3m2!1sid!2sid!4v1607498396736!5m2!1sid!2sid" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
		</div>
		</div>
	</div>
<style type="text/css"> 
footer{
    clear: both;
    background-color: #DB7093; /*ungu*/
    color: white;
    padding: 15px;
    text-align: center;
}		
</style>
	<footer>
           Copyright &copy; 2020 || by ISMI DZIKRINA Informatika
    </footer>
 
</body>
</html>