<?php
	require "functions_barang.php";
	$id_barang = $_GET["id_barang"];
	$br = query("SELECT * FROM barang WHERE id_barang=$id_barang")[0];

	$query = "SELECT * FROM barang";
	$result = mysqli_query($conn,$query);

	//cek tombol submit sudan ditekan apa belum
	if (isset($_POST['submit'])) {
	
		//cek jika data berhasil ditambahkan ,>0 artinya ada baris data yang berubah didb
		if(edit($_POST) > 0){
			echo "
					<script>
						alert('data berhasil diedit');
						document.location.href='barang.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal diedit');
						document.location.href='barang.php';
					</script>
			";
		}
		}
?>
<!-- //  -->
<!DOCTYPE html>
<html>
<head>
	<title>barang</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">
</head>
<body>
	<div class="container">

	<!-- awalcard form .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header bg-secondary text-white text-center lead">
	    FORM EDIT DATA BARANG
	  </div>
	  <div class="card-body">
	  	<form method="post" action="">
	  		<input type="hidden" name="id_buku" value="<?=$bk["id_barang"]; ?>">
	  		<div class="form-group">
	  			<label class="lead">Id Barang</label>
	  			<input type="text" name="id_barang" class="form-control" readonly value="<?=$br["id_barang"];?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Nama Barang</label>
	  			<input type="text" name="nama_barang" class="form-control" value="<?=$br["nama_barang"]; ?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Harga Barang</label>
	  			<input type="text" name="harga_barang" class="form-control" value="<?=$br["harga_barang"]; ?>" required/>
	  		</div>  
	  		<div class="form-group">
	  			<label class="lead">Stok</label>
	  			<input type="number" name="stok" min="0" max="50" class="form-control" value="<?=$br["stok"]; ?>" required/>
	  		</div>

	  		<button type="submit" class="btn btn-success" name="submit">Simpan</button>

	  	</form>
	  </div>
	</div>
	<!-- selesai card form -->
	</div>
	<br><br>
<style type="text/css"> 
footer{
    clear: both;
    background-color: #DB7093; /*ungu*/
    color: white;
    padding: 15px;
    text-align: center;
}		
</style>
	<footer>
            Copyright &copy; 2020 || by ISMI DZIKRINA Informatika
    </footer>

<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>