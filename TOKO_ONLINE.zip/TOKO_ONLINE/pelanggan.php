<?php
	require "functions_pelanggan.php";
	$pelanggan = query ("SELECT * FROM pelanggan");

	//tekan tombol cari
	if (isset($_POST["cari"])) {
		$pelanggan = cari($_POST["keyword"]);
	}
	//cek tombol submit sudan ditekan apa belum
	if (isset($_POST['submit'])) {
	
		//cek jika data berhasil ditambahkan ,>0 artinya ada baris data yang berubah didb
		if(tambah($_POST) > 0){
			echo "
					<script>
						alert('data berhasil ditambahkan');
						document.location.href='pelanggan.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal ditambahkan');
						document.location.href='pelanggan.php';
					</script>
			";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>pelanggan</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">

</head>
<body>
	<header>
		 <div class="main">
		 	<div class="logo"><img src="gambar/logo2.gif"></div>
		 	<ul>
		 		<li><a href="home.php">Home</a></li>
		 		<li><a href="barang.php">Barang</a></li>
                <li class="active"><a href="pelanggan.php">Pelanggan</a></li>
                <li><a href="transaksi.php">Transaksi</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
		 	</ul>
		 </div>
		 <div class="button">
		 	<a href="https://www.youtube.com/watch?v=JdFS_CbRMRM" class="btn1">Tonton Video</a>
		 	<a href="index.php" class="btn2">Logout</a>
		 </div>
		 <div class="title">
		 	<h1>~~~ Highwell Online Shop ~~~</h1>
		 </div>
	</header>

	<div class="container">
	
	<!-- awalcard form .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header bg-secondary text-white text-center lead">
	    FORM INPUT DATA PELANGGAN
	  </div>
	  <div class="card-body">
	  	<form method="post" action="">
	  		<div class="form-group">
	  			<label class="lead">Nama</label>
	  			<input type="text" name="nama" class="form-control" placeholder="Masukkan nama pelanggan disini...." required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Kota</label>
	  			<input type="text" name="kota" class="form-control" placeholder="Masukkan kota pelanggan disini...." required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Nomor Telephone</label>
	  			<input type="text" name="no_telp" class="form-control" placeholder="Masukkan nomor telephone disini...." required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Tanggal Lahir</label>
	  			<input type="date" name="tgl_lahir" class="form-control" placeholder="Masukkan tanggal lahir disini...." required/>
	  		</div>  

	  		<button type="submit" class="btn btn-success" name="submit">Simpan</button>
	  		<button type="reset" class="btn btn-danger" name="reset">Kosongkan</button>

	  	</form>
	  </div>
	</div>
	<!-- selesai card form -->

	<!-- pencarian -->
	<form action="#" method="post">
		<div class="input-group mb-3"> 
		<input type="text" name="keyword" size="40" autofocus placeholder="Masukkan kata pencarian..." autocomplete="off" id="keyword" class="form-control">
			<div class="input-group-append">
				<button type="submit" name="cari" id="tombolcari" class="btn btn-warning">Cari</button>
			</div>
		</div>
	</form>

	<!-- awalcard tabel .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header text-white bg-secondary text-center lead">
	    DATA PELANGGAN
	  </div>
	  <div class="card-body">
	  	<table class="table table-bordered table-striped">
	  		<tr class=" text-dark text-center">
	  			<th class="text-center">No</th>
	  			<th class="text-center">Id Pelanggan</th>
	  			<th class="text-center">Nama</th>
	  			<th class="text-center">Kota</th>
	  			<th class="text-center">Nomor Telephone</th>
	  			<th class="text-center">Tanggal Lahir</th>
	  			<th class="text-center">Aksi</th>
	  		</tr>
	  		<?php $i = 1; ?>
	  		<?php foreach ($pelanggan as $row) :	?> 
	  		<tr>
	  			<td><?=$i; ?></td>
	  			<td><?=$row['id_pelanggan']?></td>
	  			<td><?=$row['nama']?></td>
	  			<td><?=$row["kota"]?></td>
	  			<td><?=$row["no_telp"]?></td>
	  			<td><?=$row["tgl_lahir"]?></td>
	  			<td>
	  				<a href="edit_pelanggan.php?id_pelanggan=<?= $row["id_pelanggan"];?>" class="btn btn-warning">Edit</a>
	  				<a href="hapus_pelanggan.php?id_pelanggan=<?=$row["id_pelanggan"];?>"onclick="return confirm('apakah anda ingin menghapus data ?')" class="btn btn-danger">Hapus</a>
	  			</td>
	  		</tr>
	  		<?php $i++;?>
	  		<?php endforeach; ?>
	  	</table>
	  </div>
	</div>
	<!-- selesai card tabel -->
	</div>
<style type="text/css"> 
footer{
    clear: both;
    background-color: #DB7093; /*ungu*/
    color: white;
    padding: 15px;
    text-align: center;
}		
</style>
	<footer>
            Copyright &copy; 2020 || by ISMI DZIKRINA Informatika
    </footer>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>