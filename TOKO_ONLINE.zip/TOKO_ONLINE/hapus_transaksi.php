<?php
//cek untuk tombol hapus
	require "functions_transaksi.php";
	$id_transaksi=$_GET["id_transaksi"];
	if (hapus($id_transaksi)>0) {
		echo "
					<script>
						alert('data berhasil dihapus');
						document.location.href='transaksi.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal dihapus');
						document.location.href='transaksi.php';
					</script>
			";
	}

?>