<?php
	require "functions_pelanggan.php";
	$id_pelanggan = $_GET["id_pelanggan"];
	$pl = query("SELECT * FROM pelanggan WHERE id_pelanggan=$id_pelanggan")[0];

	//cek tombol submit sudan ditekan apa belum
	if (isset($_POST['submit'])) {
	
		//cek jika data berhasil ditambahkan ,>0 artinya ada baris data yang berubah didb
		if(edit($_POST) > 0){
			echo "
					<script>
						alert('data berhasil diedit');
						document.location.href='pelanggan.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal diedit');
						document.location.href='pelanggan.php';
					</script>
			";
		}
		}
?>

<!DOCTYPE html>
<html>
<head>
	<title>pelanggan</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">
</head>
<body>
	<div class="container">

	<!-- awalcard form .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header bg-secondary text-white text-center lead">
	    FORM EDIT DATA PELANGGAN
	  </div>
	  <div class="card-body">
	  	<form method="post" action="">
	  		<input type="hidden" name="id_pelanggan" value="<?=$pl["id_pelanggan"]; ?>">
	  		<div class="form-group">
	  			<label class="lead">Id Pelanggan</label>
	  			<input type="text" name="id_pelanggan" class="form-control" readonly value="<?=$pl["id_pelanggan"];?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Nama</label>
	  			<input type="text" name="nama" class="form-control" value="<?=$pl["nama"];?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Kota</label>
	  			<input type="text" name="kota" class="form-control" value="<?=$pl["kota"];?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Nomor Telephone</label>
	  			<input type="text" name="no_telp" class="form-control" value="<?=$pl["no_telp"];?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="lead">Tanggal Lahir</label>
	  			<input type="date" name="tgl_lahir" class="form-control" value="<?=$pl["tgl_lahir"];?>" required/>
	  		</div>

	  		<button type="submit" class="btn btn-success" name="submit">Simpan</button>

	  	</form>
	  </div>
	</div>
	<!-- selesai card form -->
	</div>
<style type="text/css"> 
footer{
    clear: both;
    background-color: #DB7093; /*ungu*/
    color: white;
    padding: 15px;
    text-align: center;
}		
</style>
	<footer>
            Copyright &copy; 2020 || by ISMI DZIKRINA Informatika
    </footer>

<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>