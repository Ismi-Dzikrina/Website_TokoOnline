<?php
//cek untuk tombol hapus
	require "functions_pelanggan.php";
	$id_pelanggan=$_GET["id_pelanggan"];
	if (hapus($id_pelanggan)>0) {
		echo "
					<script>
						alert('data berhasil dihapus');
						document.location.href='pelanggan.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal dihapus');
						document.location.href='pelanggan.php';
					</script>
			";
	}

?>