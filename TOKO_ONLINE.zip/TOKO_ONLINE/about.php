
<!DOCTYPE html>
<html>
<head>
	<title>about</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">
</head>
<body>
	<header>
		 <div class="main">
		 	<div class="logo"><img src="gambar/logo2.gif"></div>
		 	<ul>
		 		<li><a href="home.php">Home</a></li>
		 		<li><a href="barang.php">Barang</a></li>
                <li><a href="pelanggan.php">Pelanggan</a></li>
                <li><a href="transaksi.php">Transaksi</a></li>
                <li class="active"><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
		 	</ul>
		 </div>
		 <div class="button">
		 	<a href="https://www.youtube.com/watch?v=JdFS_CbRMRM" class="btn1">Tonton Video</a>
		 	<a href="index.php" class="btn2">Logout</a>
		 </div>
		 <div class="title">
		 	<h1>~~~ Highwell Online Shop ~~~</h1>
		 </div>
	</header>

	<div class="container">
		<div class="card mt-3"> <!-- margin top=3 -->
			<div class="card-header bg-secondary text-white text-center lead">
	    		ABOUT US
	  		</div>
	  	<div class="card-body">
	  		<table class="table table-bordered table-striped">
		  		<tr class=" text-dark text-center">
		  			<th class="text-center" width="33.3%">Ismi Dzikrina</th>
		  		</tr>
		  		<tr>
		  			<td class="text-center"><img src="gambar/ismi.jpg" height="300px" width="auto"></td>
		  		</tr>
		  		<tr>
		  			<td class="text-center">L200180010</td>
		  		</tr>
		  		<tr>
		  			<td class="text-center">Informatika UMS</td>
		  		</tr>
	  		</table>
		</div>
		</div>
	</div>
<style type="text/css"> 
footer{
    clear: both;
    background-color: #DB7093; /*ungu*/
    color: white;
    padding: 15px;
    text-align: center;
}		
</style>
	<footer>
            Copyright &copy; 2020 || by ISMI DZIKRINA Informatika
    </footer>
 



</body>
</html>