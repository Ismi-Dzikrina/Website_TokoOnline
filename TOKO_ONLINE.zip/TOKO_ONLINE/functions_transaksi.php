 <?php 
//koneksi ke database
$conn = mysqli_connect("localhost","root","","toko_online");

 function query($query){
 	global $conn;
	$result = mysqli_query($conn,$query);
	$rows = [];
	while ($row = mysqli_fetch_array($result)) {
	 	$rows[] = $row;
	} 
	return $rows;
}

function tambah($data){
	global $conn;
	//ambil semua data yang dikirim
	$id_pelanggan = htmlspecialchars($data["id_pelanggan"]);
	$id_barang = htmlspecialchars($data["id_barang"]);
	$tgl = htmlspecialchars($data["tgl"]);
	$total = htmlspecialchars($data["total"]);
	$keterangan = htmlspecialchars($data["keterangan"]);
	
	//insert data ke dalam db
	$query = "INSERT INTO transaksi VALUES ('','$id_pelanggan','$id_barang','$tgl','$total','$keterangan')";
	mysqli_query($conn,$query);
	return mysqli_affected_rows($conn);
}

function hapus($id_transaksi){
	global $conn;
	mysqli_query($conn,"DELETE FROM transaksi WHERE id_transaksi='$id_transaksi'");
	return mysqli_affected_rows($conn);
}

function edit($data){
	global $conn;
	//ambil semua data yang dikirim
	$id_transaksi =$data["id_transaksi"];
	$id_pelanggan = htmlspecialchars($data["id_pelanggan"]);
	$id_barang = htmlspecialchars($data["id_barang"]);
	$tgl = htmlspecialchars($data["tgl"]);
	$total = htmlspecialchars($data["total"]);
	$keterangan = htmlspecialchars($data["keterangan"]);
	
	//update data ke dalam db
	$query = "UPDATE transaksi SET 
					id_pelanggan='$id_pelanggan', 
					id_barang='$id_barang',
					tgl='$tgl',
					total='$total',
					keterangan='$keterangan'
			WHERE id_transaksi='$id_transaksi'
			";
	mysqli_query($conn,$query);
	return mysqli_affected_rows($conn);	
}

function cari($keyword){
	$query = "SELECT * FROM transaksi WHERE id_pelanggan LIKE '%$keyword%' OR id_barang LIKE '%$keyword%' OR tgl LIKE '%$keyword%' OR total LIKE '%$keyword%' OR keterangan LIKE '%$keyword%'";
	return query($query);
}
?>