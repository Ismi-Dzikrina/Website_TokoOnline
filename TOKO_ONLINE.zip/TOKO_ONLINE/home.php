
<!DOCTYPE html>
<html>
<head>
	<title>Perpustakaan Isdhian</title>
	<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
    <header>
		 <div class="main">
		 	<div class="logo"><img src="gambar/logo2.gif"></div>
		 	<ul>
		 		<li class="active"><a href="home.php">Home</a></li>
                <li><a href="barang.php">Barang</a></li>
                <li><a href="pelanggan.php">Pelanggan</a></li>
                <li><a href="transaksi.php">Transaksi</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
		 	</ul>
		 </div>
		 <div class="button">
		 	<a href="https://www.youtube.com/watch?v=JdFS_CbRMRM" class="btn1">Tonton Video</a>
		 	<a href="index.php" class="btn2">Logout</a>
		 </div>
		 <div class="title">
		 	<h1>~~~ Highwell Online Shop ~~~</h1>
		 </div>
	</header>
<style type="text/css">
    .kotak h3
{
    background-color: #708090;
    color: white;
    text-align: center;
    padding: 10px;
    margin-bottom: 13px;
}
</style>

	<div class="menu-kiri">
            <div class="kotak">
				<h3>Berita Hits</h3>
 
                <nav class="menu-artikel">
                    <ul>
                        <li><a href="#">UMKM dan Online Shop Wajib Tahu 8 Tips Manjur Bikin Caption Menarik di Instagram Ini!</a></li>
                        <li><a href="#">Jemput Bola, JW Marriott Jakarta Perkenalkan One-Click Shopping</a></li>
                        <li><a href="#">Tidak Asal Foto, Begini Cara Memotret Produk Agar Laris di Online Shop</a></li>
                    	<li><a href="#">Tips & Trik Membuat Katalog Produk Online Shop</a></li>
                    </ul>
                </nav>
            </div>

        </div>
 
        <div class="menu-tengah">
            <div class="kotak">
            	<table border="1" cellpadding="10" cellspacing="0">
					<tr><center><b>Barang Terlaris</b></center></tr><br>
					<tr><center><img src="gambar/barang_laris.jpg"></center></tr><br>
					<tr><p align="justify">
						Nah, buat kamu yang suka shopping barang-barang diataslah yang sering dijumpai. Mulai tunggu apa lagi ?<br>
					</tr><br>
					<tr>Yuk dapatkan Sekarang !!!</tr><br>
				</table>
            </div>
        </div>
 
         <div class="menu-kanan">
            <div class="kotak">
                <h3>Barang Terpopuler</h3>
 
                <nav class="menu-artikel">
                    <ul>
                        <li><a href="#">Handphone dan Aksesoris</a></li>
                        <li><a href="#">Skincare dan Alat kesehatan</a></li>
                        <li><a href="#">Pakaian Remaja</a></li>
                    </ul>
                </nav>
            </div>
        </div>
<style type="text/css"> 
footer{
    clear: both;
    background-color: #DB7093; /*ungu*/
    color: white;
    padding: 15px;
    text-align: center;
}       
</style>
	<footer>
            Copyright &copy; 2020 || by ISMI DZIKRINA Informatika
    </footer>

</body>
</html>