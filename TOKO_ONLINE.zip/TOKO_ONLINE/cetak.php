<html>
<head>
	<title>Data Laporan Transaksi</title>
</head>
<body>
 
	<center>
 
		<h3><font face="Arial">Data Laporan Transaksi</font></h3>
		<h2><font face="Arial">HighWell Online Shop</font></h2>

	</center>
 
	<?php 
	$conn = mysqli_connect("localhost","root","","toko_online");

	?>
 
	<table border="1" style="width: 100%">
		<tr>
			<th width="5%">No</th>
			<th>Id Pelanggan</th>
			<th>Id Barang</th>
			<th>Tanggal</th>
			<th>Total</th>
			<th>Keterangan</th>
		</tr>
		<?php 
		$no = 1;
		$sql = mysqli_query($conn,"SELECT * FROM transaksi");
		while($row = mysqli_fetch_assoc($sql)){
		?>
		<tr>
			 <td><?php echo $no++;?></td>
             <td><?php echo $row['id_pelanggan'];?></td>
             <td><?php echo $row['id_barang'];?></td>
             <td><?php echo $row['tgl'];?></td>
             <td><?php echo $row['total'];?></td>
             <td><?php echo $row['keterangan'];?></td>
		</tr>
		<?php } ?>
	</table>
 
	<script>
		window.print();
	</script>
 
</body>
</html>
